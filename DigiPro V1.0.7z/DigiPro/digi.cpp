 #include <arduino.h>
#include <avr/wdt.h>

#include "sx1278.h"
#include "digi.h"
#include "DigiPro.h"

SX1278 lora(SX1278_BW_125_00_KHZ, SX1278_SF_9, SX1278_CR_4_6);

#define RF_FREQ  433296000
#define RF_POWER 20

/* DIGIPEATER CONFIG */
//const char *DefLat  = "4819.55N";   // Tour observation
//const char *DefLong = "07824.15W";
const char *DefLat  = "4830.00N";   // Site AIG-3
const char *DefLong = "07832.00W";


const unsigned char NodeCall[7] =  { 'V'<<1,'A'<<1,'2'<<1,'A'<<1,'I'<<1,'G'<<1, 0x68 };  // Change CALLSIGN HERE, and just below
const unsigned char DigiDest[7] =  { 'A'<<1,'P'<<1,'E'<<1,'T'<<1,'1'<<1,'0'<<1, 0x60 };
const unsigned char DigiPath[7] =  { 'W'<<1,'I'<<1,'D'<<1,'E'<<1,'2'<<1,' '<<1, 0x64 };
#define NodeMsg PSTR(":VA2AIG-4 :")                                                      // Change CALLSIGN here too

#define BCN_SYMBOL_TABLE '/'
#define BCN_SYMBOL_ID    '#'
#define B1_INTERVAL 1000  
#define B2_INTERVAL 1550
#define B3_INTERVAL 1750
#define DUP_DELAY 10
#define WIDEN_MAX 3

/* TELEMETRY CONFIG */
#define TELEM_INTERVAL 950
const char TelemSequence[] = { 1,1,1,4,1,1,1,3,1,1,1,2,1,1,1,0 }; 

/* RADIO CHANNEL CONFIG */
#define CHANNEL_SLOTTIME 100
#define CHANNEL_PERSIST 63

/* LORA MODEM HEADER DEF */
#define HEADER_TYPE_AX25 0xA3

#define DUP_MAXFRAME 10             /* Maximum duplicate frame memory */

static unsigned char pkt[255], index;


/********************************************************************************/

/* Duplicate frame table */
struct TDupFrame {
    unsigned long time;   // Time when receive packet (if 0, empty slot)
    uint16_t crc;           // CRC of data block
} TDupFrame;

struct TDupFrame DupFrame[DUP_MAXFRAME];

/* Beacon timer */
unsigned long Beacon1Timer;     // Value of Timer for next beacon transmission
unsigned long Beacon2Timer; 
unsigned long Beacon3Timer;     // System beacon (Version and up-time)
unsigned long TelemTimer;       // Telemetry timer 

unsigned short stat_digipeated_pkt;  // Number en packet digipeated

/******************************************************************************
 * String copy with NULL padding
 *****************************************************************************/
void strncpy_0pad(char *dest, char *src, int n) {   
  while(n--) { 
    if(*src==0) *(dest++) = '0'; else *(dest++) = *(src++);
  }                       
  *dest = 0;
}

/******************************************************************************
 * Check timer overflow
 *****************************************************************************/
long TimerOverflow(unsigned long value) {
    return (long)(value-wdt_clk) < 0 ? 1:0;
}   

/******************************************************************************
 * Watch clear channel, 100ms slottime, persistance 63.
 *****************************************************************************/
void WaitClearChannel() {
    uint32_t t;
    return;

    do {
        t = millis() + CHANNEL_SLOTTIME;      
        do {
            if(lora.rxBusy()) t = millis() + CHANNEL_SLOTTIME;      
        } while(millis() < t);  
    } while(random(0,256) > CHANNEL_PERSIST);
}

/******************************************************************************
 * Packet handling fonction
 * 
 * Create and manage packet.
 *****************************************************************************/
void CreatePacket() {
    uint8_t i;
        
    /* LORA HEADER */
    index=0;
    pkt[index++] = HEADER_TYPE_AX25;
    
     /* SEND SOURCE/DEST CALLSIGN */    
    for(i=0; i<7; i++) pkt[index++] = DigiDest[i];  // Dest call
    for(i=0; i<7; i++) pkt[index++] = NodeCall[i];  // Source call

    /* PATH */
    if(DigiPath[0]!=(' ' << 1)) {
        for(i=0; i<7; i++) pkt[index++] = DigiPath[i];
    }

    /* UI FRAME AND PID */
    pkt[index-1] |= 1;  // Finalize path here
    pkt[index++] = 0x03;    /* UI Frame */
    pkt[index++] = 0xF0;    /* PID */                                                      
}

void SendPacket() {
    WaitClearChannel();
    lora.tx(pkt, index);
    while(lora.txBusy());
}

/******************************************************************************
 * void DigiSendBeacon(uint8_t id)
 * 
 * Create and send digipeater beacon to Lora radio.
 *****************************************************************************/
void DigiSendBeacon(uint8_t id) {

    /* CREATE NEW PACKET */
    CreatePacket();
    
    /* SYSTEM STATUS BEACON?*/
    if(id == 2) {
        char tmp[6];
        dtostrf(Temp, 5, 1, tmp);
        index += sprintf((char*)&pkt[index], ">%u mV (%s) T=%sC", batt_volt, sleep_flag?"SLEEP":"ACTIVE", tmp);
       
    } else {
      
        /* 1ST ICON, LATITUDE, LONGITUDE AND 2ND SYMBOL */  
        pkt[index++] = '!';     /* The "!" Symbol means no time stamp */
        strncpy_0pad((char*)&pkt[index], (char*)DefLat, 8); 
        index += 8;
        pkt[index++] = BCN_SYMBOL_TABLE;
        strncpy_0pad((char*)&pkt[index], (char*)DefLong, 9); 
        index += 9;
        pkt[index++] = BCN_SYMBOL_ID;
 
        /* COMMENT */
        switch(id) {
            case 0:  index += sprintf_P((char*)&pkt[index], PSTR("433.300 MHz 20dbm B125 SF9 CR46"));  break; 
            case 1:  index += sprintf_P((char*)&pkt[index], PSTR("Lora digipeater V1.0, Preissac.")); break; 
        }
    }

    SendPacket();
}

/******************************************************************************
 * void DigiSendTelem()
 * 
 * Send telemetry to radio.
 *****************************************************************************/
void DigiSendTelem() {
    uint8_t i, spc_count;
    static unsigned char seq,seq_cnt;    
    
     /* CREATE NEW PACKET */
    CreatePacket();
 
    /* CREATE APRS MESSAGE HEADER ONLY FOR TELEMETRY PARAMETERS */
    if(TelemSequence[seq]!=1) index += sprintf_P((char*)&pkt[index], NodeMsg);
     
    /* FINISH TELEM PACKET */
    uint8_t param1 = ((float)batt_volt/1000.0 - 2.5) / 0.008;
    uint8_t param2 = (Temp + 60.0) / 0.5;
    
    switch(TelemSequence[seq++]) {
        case 1:  index += sprintf_P((char*)&pkt[index], PSTR("T#%03u,%03u,%03u,000,000,000,00000000"), seq_cnt++, param1, param2);  break; 
        case 2:  index += sprintf_P((char*)&pkt[index], PSTR("PARM.Vbatt,Temp")); break;
        case 3:  index += sprintf_P((char*)&pkt[index], PSTR("UNIT.Volt,C")); break;
        case 4:  index += sprintf_P((char*)&pkt[index], PSTR("EQNS.0,0.008,2.5,0,0.5,-60")); break;
    }

    /* RESET SEQUENCE AT END AND SET FINAL PACKET SIZE */
    if(TelemSequence[seq]==0) seq=0;

    SendPacket();
}

/******************************************************************************
 * unsigned short DoCRC(unsigned short crc, unsigned char c)
 * 
 * Compute CRC.
 *****************************************************************************/
unsigned short DoCRC(unsigned short crc, unsigned char c) {
    unsigned short xor_int;

    for (uint8_t i=0; i<8; i++) {       
        xor_int = crc ^ (c&1);
        crc>>=1;
        if(xor_int & 0x0001) crc ^= 0x8408;
        c >>=1;                  
    }

    return crc;
}

/******************************************************************************
* TestDup
*
* Return TRUE if packet given is already in duplicate table. Clear also old
* frame.
******************************************************************************/
int TestDup(unsigned char *p, int size) {
    uint8_t i,flag;
    uint16_t pkt_crc=0xFFFF;

    /* COMPUTE CRC*/
    for(i=0; i<size; i++) pkt_crc = DoCRC(pkt_crc, p[i]);
    
    /* CHECK FOR DUPLICATE, CLEAR OLD FRAME */
    for(i=0,flag=0; i<DUP_MAXFRAME; i++) {
        if(TimerOverflow(DupFrame[i].time)) DupFrame[i].time=0;  /* Clear old frame */      
        if(DupFrame[i].time==0) continue;                        /* Skip if slot is empty */
        if(DupFrame[i].crc==pkt_crc) flag=1;                     /* !! Find duplicate packet */
    } 

    return flag;
}


/******************************************************************************
* AddDupList
*
* Add packet to duplicate table. If table is full, oldest is deleted and
* replaced by the new.
*
* Only Data field is keeped for comparaison. Only UI frame.
******************************************************************************/
void AddDupList(unsigned char *p, int size) {
    uint8_t i,old;
    uint32_t oldest_time;
    uint16_t pkt_crc=0xFFFF;

    /* COMPUTE CRC*/
    for(i=0; i<size; i++) pkt_crc = DoCRC(pkt_crc, p[i]);

    /* PLACE FRAME INTO FIRST EMPTY SLOT */
    for(i=0; i<DUP_MAXFRAME; i++) {
        if(DupFrame[i].time==0) {
            DupFrame[i].time = wdt_clk + DUP_DELAY;
            DupFrame[i].crc = pkt_crc;
            return;
        }
    }

    /* LIST IS FULL, FIND OLDEST FRAME */
    old = 0;
    oldest_time = DupFrame[0].time;
    for(i=1; i<DUP_MAXFRAME; i++) {
        if( (long)(DupFrame[i].time-oldest_time)<0 ) {
            old = i;
            oldest_time = DupFrame[i].time;
        }
    }

    /* REPLACE OLDEST FRAME BY NEW */
    DupFrame[old].time = wdt_clk + DUP_DELAY;
    DupFrame[old].crc = pkt_crc;
}

/******************************************************************************
* DigiRepeat
* 
* Send digipeated packet and update stat
******************************************************************************/
void DigiRepeat(unsigned char *packet, int packet_size) {
    WaitClearChannel();
    lora.tx(packet, packet_size);
    while(lora.txBusy());
    stat_digipeated_pkt++;
}

/******************************************************************************
 * void DigiRules(unsigned char *packet, int packet_size)
 * 
 * Apply digipeater rule to packet and digipeat if needed.ex
 *
 * Buffer Format:
 * Destination call : 6 byte + 1 bytes (CALL + SSID) SSID bit 4:1
 * Source call      : 6 byte + 1 bytes (CALL + SSID)
 * Path             : 6 byte + 1 bytes (CALL + SSID)   
 *                    ... up to 7 digipeting path, end with bit 0 of SSID set
 * Control          : 1 byte (must be UI frame)
 * PID              : 1 byte (don't care)                                              
 * Data frame       : variable
 * 
 * Rule:
 * -Reject any non-UI frame
 * -Reject packet from this node (Source call = Node call)
 * -Trig beacon 1 if data frame contain ?APRS?
 * -Trig beacon 3 and telemetry  if data frame contain :<nodecall>:?APRSS and exit
 * -Test if packet is in duplicate list
 * -Process generic SSID digipeating
 * -Reject if no path
 * -Test for WIDEn-n
 ******************************************************************************/
void DigiRules(unsigned char *packet, uint8_t packet_size) {
    uint8_t DataIndex,PathIndex,i, NodeBufIndex;  
    unsigned char flag,ssid,c; 
    unsigned char tmp[9], *NodeBuf; 

    /* REJECT NON AX25 FRAME */
    if(packet[0] != HEADER_TYPE_AX25) return;
    NodeBuf = &packet[1];
    NodeBufIndex = packet_size-1;
    
    /* REJECT NON-UI FRAME, FIND DATA FRAME (DataIndex) */
    for(DataIndex=0; DataIndex<NodeBufIndex; DataIndex++) if(NodeBuf[DataIndex]&1) break;
    if(NodeBuf[++DataIndex]!=0x03) return;   
    DataIndex+=2;   /* Skip PID */
    
    /* TEST FOR PACKET FROM THIS NODE */
    for(i=0, flag=0; i<7; i++) { 
        if(i!=6) {
            if(NodeBuf[7+i]!=NodeCall[i]) { flag=1; break; }   
        } else {
            if((NodeBuf[7+i]&0x1E)!=(NodeCall[i]&0x1E)) { flag=1; break; }   
        }
    }
    if(flag==0) return; 

    /* TEST FOR DUPLICATE PACKET */
    if(TestDup(&NodeBuf[DataIndex],NodeBufIndex-DataIndex)) return; 

    /* TEST FOR ?APRS? QUERY */
    for(i=0, flag=0; i<6; i++) if(NodeBuf[i+DataIndex]!="?APRS?"[i]) { flag=1; break; }
    if(flag==0) Beacon1Timer=wdt_clk; 
  
    /* TEST FOR ?APRSS FOR THIS NODE */
    flag=0;
    for(i=0; i<6; i++) if(NodeBuf[11+i+DataIndex]!="?APRSS"[i]) { flag=1; break; }   
    for(i=0; i<6; i++) { if(NodeCall[i]==(' '<<1)) break; tmp[i]=NodeCall[i]>>1; } // Set node call
    ssid=(NodeCall[6]>>1)&15; 
    if(ssid) { 
        tmp[i++]='-';
        if(ssid>9) { 
            tmp[i++]='1'; 
            ssid-=10; 
        }
        tmp[i++] = '0'+ssid;
    }
    while(i!=9) tmp[i++] = ' ';     

    for(i=0; i<9; i++) if(NodeBuf[1+i+DataIndex]!=tmp[i]) { flag=1; break; } 
    if(flag==0) {  Beacon3Timer=wdt_clk; }

    /* TEST FOR SSID DIGIPEATING */ 
    ssid = (NodeBuf[6]&0x1E)>>1;
    if(ssid!=0 && ssid<=WIDEN_MAX) {
        NodeBuf[6] = (NodeBuf[6]&0xE1) | ((ssid-1)<<1);   // Decrement SSID
        AddDupList(&NodeBuf[DataIndex],NodeBufIndex-DataIndex);
        DigiRepeat(packet, packet_size);  
        return;
    }

    /* REJECT PACKET IF NO PATH */
    if(NodeBuf[13]&1) return;

    /* TEST PATH FOR WIDEn-n */
    PathIndex = 14;
    while(1) {     
        if( (NodeBuf[PathIndex+6]&0x80) == 0) { 
                    
            /* GET SSID */
            ssid = (NodeBuf[PathIndex+6]&0x1E)>>1; 
            flag=0;
            for(i=0; i<4; i++) { if(NodeBuf[PathIndex+i]!=("WIDE"[i])<<1) flag=1; } /* Call must be WIDE */
            if(ssid==0 || ssid>WIDEN_MAX) flag=1;  /* ssid must be 1 to wide-n maximum */
            c = NodeBuf[PathIndex+4]>>1;
            if(c<'1' || c>('0'+WIDEN_MAX)) flag=1;  /* Test WIDEn : n must be between 1 and maximum */

            if(flag==0) {
                ssid--;                         /* decrement SSID */
                NodeBuf[PathIndex+6] = (NodeBuf[PathIndex+6]&0xE1) | (ssid<<1);   
 
                /* MAKE ROOM FOR DIGICALL IF SSID IS NOT 0 */
                if(ssid) {
                    for(i=(NodeBufIndex-1); i>=PathIndex; i--) NodeBuf[i+7] = NodeBuf[i];
                    NodeBuf[PathIndex+6] = 0; // Clear end of path bit
                    DataIndex+=7;
                    NodeBufIndex+=7;
                    packet_size+=7;
                }

                /* COPY DIGI CALL TO PATH  */
                for(i=0; i<6; i++) NodeBuf[PathIndex+i] = NodeCall[i];
                NodeBuf[PathIndex+6] = (NodeBuf[PathIndex+6]&0xE1) | (NodeCall[6]&0x1E);
                NodeBuf[PathIndex+6] |= 0x80;     /* Set has-been-repeated bit */   

                /* DIGIPEAT IT */
                AddDupList(&NodeBuf[DataIndex],NodeBufIndex-DataIndex);
                DigiRepeat(packet, packet_size);
                return;  
            }                                                               
            return;   // If no rules apply to current digi path, exit now.
        }
    
        if(NodeBuf[PathIndex+6]&1) break;       // Stop at end of path 
        PathIndex+=7;
    } 
}

/******************************************************************************
 * void DigiPoll()
 *
 * Check if beacon are timeout, transmit.
 *****************************************************************************/
int DigiPoll() {
    static uint8_t status, length;
    
    status = lora.rxAvailable(pkt, &length);
    if(status==ERR_NONE) {
        DigiRules(pkt, length);
        return 1;
    }

    /* BEACON 1 TIMEOUT */
    if(TimerOverflow(Beacon1Timer)!=0 ) { 
        DigiSendBeacon(0);
        Beacon1Timer = wdt_clk + (uint32_t)B1_INTERVAL;
        return 1;
    }

    /* BEACON 2 TIMEOUT */
    if(TimerOverflow(Beacon2Timer)!=0 ) {
        DigiSendBeacon(1);
        Beacon2Timer = wdt_clk + (uint32_t)B2_INTERVAL;
        return 1;
    }

    /* BEACON 3 TIMEOUT */
    if(TimerOverflow(Beacon3Timer)!=0 ) {
        DigiSendBeacon(2);
        Beacon3Timer = wdt_clk + (uint32_t)B3_INTERVAL;
        return 1;
    }

    /* TELEMETRY TIMEOUT */
    if(TimerOverflow(TelemTimer)!=0) {
        DigiSendTelem();
        TelemTimer = wdt_clk + (uint32_t)TELEM_INTERVAL; 
        return 1;
    }

    return 0; 
}

/******************************************************************************
 * void DigiSleep()
 *
 * Put radio module in sleep.
 *****************************************************************************/
void DigiSleep() {
    lora.setMode(SX1278_SLEEP);  
}

/******************************************************************************
 * void DigiInit()
 *
 * Initialize digi radio module.
 *****************************************************************************/
int DigiInit() {
    if(lora.begin() == ERR_CHIP_NOT_FOUND) return 0;   
    lora.setFrequency(RF_FREQ);     // -3khz correction 
    lora.setPower(RF_POWER);        // dbm (max 20)
    return 1;
}
