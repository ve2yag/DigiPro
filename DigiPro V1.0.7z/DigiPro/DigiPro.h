#define BAT_CAL 4540L   // (float)batt_volt * BAT_CAL / 1023  In millivolts

//#define DEBUG 1

extern volatile uint32_t wdt_clk;
extern uint16_t batt_volt;
extern float Temp;
extern bool sleep_flag;
