#include <arduino.h>

/* Transmit digipeater beacon */
int DigiInit();
void DigiSleep();
int DigiPoll();
void DigiSendBeacon(uint8_t id);
